$(document).ready(function() {
  $('#service_accepted_payments').select2();
});
