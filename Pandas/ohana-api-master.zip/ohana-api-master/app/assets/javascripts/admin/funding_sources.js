$(document).ready(function() {
  $('#service_funding_sources,#organization_funding_sources').select2();
});
