OHANA_API_VERSION = File.read('VERSION').chomp
