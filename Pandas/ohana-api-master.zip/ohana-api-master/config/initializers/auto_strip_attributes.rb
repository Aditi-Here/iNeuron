AutoStripAttributes::Config.setup do
  filters_enabled[:squish] = true
end
